import React, { useState } from "react";
import axios from "axios";

function App() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [token, setToken] = useState("");

  const handleLogin = async () => {
    try {
      const response = await axios.post("http://127.0.0.1:8000/api/token/", {
        username,
        password,
      });

      console.log("Response:", response.data);

      // Token save
      setToken(response.data.access);
      localStorage.setItem("token", response.data.access);

      alert("Login Successful!");
    } catch (error) {
      console.error(error);
      alert("Login Failed!");
    }
  };

  const callProtectedAPI = async () => {
    const storedToken = localStorage.getItem("token");
    try {
      const res = await axios.get("http://127.0.0.1:8000/api/protected/", {
        headers: {
          Authorization: `Bearer ${storedToken}`,
        },
      });
      alert("Protected Data: " + JSON.stringify(res.data));
    } catch (err) {
      console.error(err);
      alert("Access Denied!");
    }
  };

  return (
    <div style={{ padding: "50px" }}>
      <h2>React JWT Demo</h2>
      <input
        type="text"
        placeholder="Username"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
      />
      <br />
      <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
      <br />
      <button onClick={handleLogin}>Login</button>
      <button onClick={callProtectedAPI}>Call Protected API</button>
      <p>Token: {token}</p>
    </div>
  );
}

export default App;